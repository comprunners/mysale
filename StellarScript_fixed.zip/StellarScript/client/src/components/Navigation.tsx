import { Link, useLocation } from "wouter";
import { ThemeToggle } from "./ThemeToggle";
import { Zap } from "lucide-react";

export function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/order-tracking", label: "Track Order" },
    { path: "/reviews", label: "Reviews" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 backdrop-blur-xl bg-background/80 border-b border-border/50">
      <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 hover-elevate active-elevate-2 px-2 py-1 rounded-md transition-colors" data-testid="link-home">
          <Zap className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold bg-gradient-to-r from-primary to-cyan bg-clip-text text-transparent">
            StellarX
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors hover-elevate active-elevate-2 ${
                  location === item.path
                    ? "text-primary"
                    : "text-muted-foreground"
                }`}
                data-testid={`link-${item.label.toLowerCase().replace(' ', '-')}`}
              >
                {item.label}
              </a>
            </Link>
          ))}
        </div>

        <ThemeToggle />
      </div>
    </nav>
  );
}
