import { ReviewCard } from "./ReviewCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";

export function ReviewsSection() {
  const [reviewText, setReviewText] = useState("");
  const [hasVerifiedPurchase] = useState(false);

  const reviews = [
    {
      name: "Alex Johnson",
      review: "Absolutely amazing service! The userscript works flawlessly and saved me countless hours. Worth every penny!",
      date: "2 days ago",
      verified: true,
    },
    {
      name: "Sarah Chen",
      review: "The Pro Plan is perfect for my needs. Great support team and the auto-clicker feature is incredibly smooth.",
      date: "1 week ago",
      verified: true,
    },
    {
      name: "Mike Rodriguez",
      review: "Best investment I've made. The Ultimate Plan handles everything seamlessly. Highly recommend!",
      date: "2 weeks ago",
      verified: true,
    },
  ];

  const handleSubmitReview = () => {
    console.log("Review submitted:", reviewText);
    setReviewText("");
  };

  return (
    <section className="py-20 px-6">
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold">Customer Reviews</h2>
          <p className="text-lg text-muted-foreground">
            See what our verified customers have to say
          </p>
        </div>

        <div className="space-y-4">
          {reviews.map((review, index) => (
            <ReviewCard key={index} {...review} />
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Leave a Review</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              placeholder={
                hasVerifiedPurchase
                  ? "Share your experience..."
                  : "Only verified purchasers can leave reviews. Complete a purchase to unlock this feature."
              }
              disabled={!hasVerifiedPurchase}
              className="min-h-32 resize-none"
              data-testid="textarea-review"
            />
            <Button
              onClick={handleSubmitReview}
              disabled={!hasVerifiedPurchase || !reviewText.trim()}
              data-testid="button-submit-review"
            >
              Submit Review
            </Button>
            {!hasVerifiedPurchase && (
              <p className="text-sm text-muted-foreground">
                Reviews are restricted to verified purchasers only.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
