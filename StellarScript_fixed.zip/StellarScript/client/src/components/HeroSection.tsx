import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowRight, Key } from "lucide-react";
import { useState } from "react";

export function HeroSection() {
  const [accessKey, setAccessKey] = useState("");
  const [keyLoaded, setKeyLoaded] = useState(false);

  const handleLoadKey = () => {
    if (accessKey.trim()) {
      setKeyLoaded(true);
      console.log("Key loaded:", accessKey);
    }
  };

  return (
    <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-cyan/10" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center space-y-8">
        <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
          Premium Digital Services for
          <span className="bg-gradient-to-r from-primary to-cyan bg-clip-text text-transparent">
            {" "}Excellence
          </span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          Access powerful automation tools and premium assignment assistance with our exclusive userscript platform.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 items-center justify-center max-w-xl mx-auto">
          <div className="relative flex-1 w-full">
            <Key className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Enter your access key..."
              value={accessKey}
              onChange={(e) => setAccessKey(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLoadKey()}
              className="h-14 pl-12 font-mono bg-card border-border rounded-lg"
              data-testid="input-access-key"
            />
          </div>
          <Button
            onClick={handleLoadKey}
            disabled={!accessKey.trim()}
            className="h-14 px-8 text-base"
            data-testid="button-load-key"
          >
            Load Key
          </Button>
        </div>

        {keyLoaded && (
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-center animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Button size="lg" className="group" data-testid="button-view-services">
              View Services
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button size="lg" variant="outline" className="backdrop-blur-md" data-testid="button-download-userscript">
              Download Userscript
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
