# StellarX Design Guidelines

## Design Approach
**Reference-Based Approach** drawing inspiration from modern digital product platforms: Stripe's payment elegance, Linear's sleek minimalism, and Discord's tech-forward aesthetic. The design must convey trust, innovation, and exclusivity fitting a premium digital services platform.

## Core Design Principles
1. **Tech-Forward Sophistication**: Sleek, modern interface that feels cutting-edge
2. **Trust Through Polish**: Every interaction reinforces professionalism and security
3. **Controlled Energy**: Strategic use of color and motion for impact without chaos
4. **Draggable Delight**: Smooth, satisfying micro-interactions for all movable elements

## Color Palette

**Dark Mode Primary** (main aesthetic):
- Background: 222 14% 8% (deep slate, almost black)
- Surface: 222 14% 12% (elevated cards/panels)
- Border: 222 10% 20% (subtle divisions)

**Light Mode** (alternative):
- Background: 0 0% 100% (pure white)
- Surface: 220 13% 97% (soft gray cards)
- Border: 220 13% 91% (gentle divisions)

**Brand Colors**:
- Primary: 258 90% 66% (electric purple - buttons, CTAs, key interactive elements)
- Primary Hover: 258 90% 60% (deeper purple)
- Accent: 192 91% 48% (cyan - success states, highlights, secondary CTAs)

**Semantic Colors**:
- Success: 142 76% 36% (green - purchase confirmation, valid keys)
- Error: 0 84% 60% (red - validation errors)
- Warning: 38 92% 50% (amber - notifications)

## Typography

**Font Families**:
- Primary: 'Inter' (headers, UI, body) - via Google Fonts
- Monospace: 'JetBrains Mono' (keys, codes, technical elements) - via Google Fonts

**Type Scale**:
- Hero: text-6xl font-bold (60px)
- H1: text-5xl font-bold (48px)
- H2: text-4xl font-semibold (36px)
- H3: text-2xl font-semibold (24px)
- Body Large: text-lg (18px)
- Body: text-base (16px)
- Small: text-sm (14px)
- Tiny: text-xs (12px)

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24 for consistent rhythm
- Tight spacing: 2-4 (within components)
- Medium spacing: 6-8 (between related elements)
- Generous spacing: 12-20 (between sections)
- Hero spacing: 24+ (dramatic separation)

**Container Widths**:
- Full sections: w-full with inner max-w-7xl mx-auto
- Content sections: max-w-6xl
- Forms/Focused content: max-w-2xl

**Grid Patterns**:
- Service cards: grid-cols-1 md:grid-cols-3 gap-6
- Features: grid-cols-1 md:grid-cols-2 gap-8
- Single column for forms and tracking

## Component Library

### Navigation
- Fixed top navigation with blur backdrop (backdrop-blur-xl bg-background/80)
- Logo left, navigation center, CTA button right
- Height: h-16
- Subtle bottom border (border-b border-border/50)

### Hero Section
- Height: min-h-[600px] (not forced 100vh)
- Subtle gradient overlay background (from purple to cyan, very subtle)
- Large hero typography with gradient text effect on key phrases
- Primary CTA: Large purple button with glow effect
- Secondary CTA: Outline button with blurred background

### Service Cards
- Elevated cards: bg-surface border border-border rounded-2xl
- Padding: p-8
- Hover: Subtle lift (transform translateY(-4px)) and border glow
- Price typography: Large, bold numbers (text-5xl) with small currency symbol
- Feature lists: Check icons (Heroicons) in accent cyan color
- CTA button per card: Full-width purple button

### Draggable Widget
- Small circular or rounded-square trigger (64x64px)
- Position: fixed bottom-6 right-6 initially
- Glass morphism effect: backdrop-blur-lg bg-surface/90 border border-border/50
- Box shadow: Prominent (shadow-2xl)
- Drag handle indicator: Subtle grip dots or cursor change
- Expanded state: Slide out panel (280px wide) with navigation shortcuts

### Payment Form
- Card-style layout: bg-surface rounded-2xl p-8 border border-border
- Input fields: Dark backgrounds (bg-background) with border-border borders
- Focus states: Purple ring (ring-2 ring-primary)
- Card number input: Monospace font, auto-spacing (4-digit groups)
- Lock icon (Heroicons) beside secure elements
- Processing state: Animated spinner, disabled inputs

### Order Tracking
- Clean status timeline with color-coded stages
- Key display: Monospace font in highlighted box with copy button
- Status badges: Rounded full pills with semantic colors

### Review Section
- Card-based layout with user avatars (placeholder circles with initials)
- Star ratings: Gold/yellow stars (38 92% 50%)
- Verified purchaser badge: Small cyan badge with checkmark
- Submit form: Only visible after purchase verification

### Real-Time Chat
- Trigger: Circular button, 56px diameter, fixed bottom-6 left-6
- Icon: Chat bubble (Heroicons), animated notification dot when unread
- Expanded window: 360px wide, 480px tall, rounded-2xl
- Message bubbles: User messages (purple), responses (surface)
- Scrollable history: Custom scrollbar styling
- Input: Fixed bottom with send button

### Key Input Interface
- Prominent placement: Either in hero or dedicated section
- Large rectangular input: h-14, rounded-lg, monospace font
- Placeholder: "Enter your access key..."
- Load button: Purple, positioned right of input or below
- No validation alerts - silent success with UI state change

### Userscript Download Button
- Styled as secondary action: Outline style with download icon
- State management: Disabled (opacity-50) until key loaded, enabled (purple accent) after
- Icon: Download icon (Heroicons) with filename text

## Animations & Interactions

**Minimal, Purposeful Motion**:
- Hover lifts: 2-4px translateY with 200ms ease
- Button presses: Subtle scale (0.98) on active
- Page transitions: Fade-in on load (opacity 0 to 1, 300ms)
- Draggable elements: Smooth cursor following, spring physics
- Chat messages: Slide-in from bottom (translateY 20px to 0)
- **No excessive animations** - maintain professional feel

## Images

**Hero Section**:
- Large background image: Abstract tech/digital network visualization or gradient mesh
- Overlay: Dark gradient (from transparent to background color) for text legibility
- Optional: Floating 3D illustrations or mockups of the userscript menu

**Service Cards**:
- Small icon illustrations per tier (custom or placeholder)
- Abstract geometric patterns as subtle backgrounds

**Trust Section**:
- Security badge icons (lock, shield, verified)
- No user photos - maintain digital, tech-focused aesthetic

## Special Considerations

**Draggable Elements**:
- Cursor: grab when hoverable, grabbing when dragging
- Z-index hierarchy: Dragging element always on top (z-50)
- Drop shadow: Increase during drag (shadow-2xl)
- Smooth transitions: Use transform for position changes

**Dark Mode Dominance**:
- Design primarily for dark mode
- Light mode as alternative, maintaining contrast ratios
- Form inputs: Distinct background in both modes

**Key Security UX**:
- Key input: No echo dots (show actual characters in monospace)
- Obfuscated validation: No error messages, just disabled/enabled states
- Admin key: No visual distinction from regular keys

**Responsive Breakpoints**:
- Mobile: Single column, stacked cards, collapsible chat
- Tablet (md:): 2-column grids where appropriate
- Desktop (lg:): Full 3-column service grid, expanded layouts

This design creates a premium, tech-forward digital services platform that balances sophistication with approachability, trust with excitement.