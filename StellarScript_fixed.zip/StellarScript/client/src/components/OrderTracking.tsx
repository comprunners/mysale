import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Copy, Check } from "lucide-react";

export function OrderTracking() {
  const [orderId, setOrderId] = useState("");
  const [orderFound, setOrderFound] = useState(false);
  const [copied, setCopied] = useState(false);

  const mockOrder = {
    id: "ORD-12345",
    plan: "Pro Plan",
    status: "Completed",
    accessKey: "SX-PRO-ABC123XYZ",
    date: "January 28, 2025",
  };

  const handleSearch = () => {
    if (orderId.trim()) {
      setOrderFound(true);
      console.log("Searching for order:", orderId);
    }
  };

  const handleCopyKey = () => {
    navigator.clipboard.writeText(mockOrder.accessKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="py-20 px-6 min-h-[calc(100vh-4rem)] flex items-center justify-center">
      <div className="max-w-2xl mx-auto w-full space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">Order Tracking</h1>
          <p className="text-lg text-muted-foreground">
            Enter your order ID to view status and access key
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Track Your Order</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Enter order ID (e.g., ORD-12345)"
                  className="pl-10"
                  data-testid="input-order-id"
                />
              </div>
              <Button onClick={handleSearch} data-testid="button-search-order">
                Search
              </Button>
            </div>

            {orderFound && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center justify-between py-3 border-b">
                  <span className="text-sm text-muted-foreground">Order ID</span>
                  <span className="font-mono font-semibold">{mockOrder.id}</span>
                </div>

                <div className="flex items-center justify-between py-3 border-b">
                  <span className="text-sm text-muted-foreground">Plan</span>
                  <span className="font-semibold">{mockOrder.plan}</span>
                </div>

                <div className="flex items-center justify-between py-3 border-b">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <Badge className="bg-success/10 text-success border-success/20">
                    {mockOrder.status}
                  </Badge>
                </div>

                <div className="flex items-center justify-between py-3 border-b">
                  <span className="text-sm text-muted-foreground">Date</span>
                  <span className="text-sm">{mockOrder.date}</span>
                </div>

                <div className="pt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Your Access Key</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleCopyKey}
                      data-testid="button-copy-key"
                    >
                      {copied ? (
                        <>
                          <Check className="h-4 w-4 mr-1" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4 mr-1" />
                          Copy
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="bg-card border rounded-lg p-4 font-mono text-lg text-center tracking-wider">
                    {mockOrder.accessKey}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
