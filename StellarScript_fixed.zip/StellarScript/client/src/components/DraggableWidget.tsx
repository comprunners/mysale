import { useState } from "react";
import Draggable from "react-draggable";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GripVertical, Home, ShoppingCart, MessageCircle, X } from "lucide-react";
import { Link } from "wouter";

export function DraggableWidget() {
  const [expanded, setExpanded] = useState(false);

  return (
    <Draggable handle=".drag-handle" bounds="body">
      <div className="fixed bottom-6 right-6 z-50" style={{ cursor: "grab" }}>
        <Card className={`backdrop-blur-lg bg-card/90 border-border/50 shadow-2xl transition-all duration-300 ${
          expanded ? "w-64" : "w-16"
        }`}>
          <div className="p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="drag-handle cursor-grab active:cursor-grabbing p-1 hover-elevate active-elevate-2 rounded">
                <GripVertical className="h-5 w-5 text-muted-foreground" />
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0"
                onClick={() => setExpanded(!expanded)}
                data-testid="button-toggle-widget"
              >
                {expanded ? (
                  <X className="h-4 w-4" />
                ) : (
                  <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
                )}
              </Button>
            </div>

            {expanded && (
              <div className="mt-4 space-y-2 animate-in fade-in slide-in-from-right-4 duration-300">
                <Link href="/">
                  <Button variant="ghost" className="w-full justify-start gap-2" data-testid="widget-button-home">
                    <Home className="h-4 w-4" />
                    <span className="text-sm">Home</span>
                  </Button>
                </Link>
                <Link href="/order-tracking">
                  <Button variant="ghost" className="w-full justify-start gap-2" data-testid="widget-button-orders">
                    <ShoppingCart className="h-4 w-4" />
                    <span className="text-sm">Orders</span>
                  </Button>
                </Link>
                <Link href="/reviews">
                  <Button variant="ghost" className="w-full justify-start gap-2" data-testid="widget-button-reviews">
                    <MessageCircle className="h-4 w-4" />
                    <span className="text-sm">Reviews</span>
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </Card>
      </div>
    </Draggable>
  );
}
