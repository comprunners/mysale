import { ServiceCard } from "./ServiceCard";

export function ServicesSection() {
  const services = [
    {
      title: "Basic Plan",
      price: 5,
      description: "25 Assignments Per/Day For Whole Week",
      features: [
        "25 assignments daily",
        "7-day access",
        "Auto-clicker tool",
        "Email support",
      ],
    },
    {
      title: "Pro Plan",
      price: 10,
      description: "50 Assignments Per/day For Week",
      features: [
        "50 assignments daily",
        "7-day access",
        "Auto-clicker tool",
        "Priority support",
        "Extended features",
      ],
      isPopular: true,
    },
    {
      title: "Ultimate Plan",
      price: 20,
      description: "Finish All Work",
      features: [
        "Unlimited assignments",
        "Complete everything",
        "Auto-clicker tool",
        "24/7 priority support",
        "All premium features",
      ],
    },
  ];

  const handlePurchase = (planTitle: string) => {
    console.log(`Purchase initiated for: ${planTitle}`);
  };

  return (
    <section className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl font-bold">Choose Your Plan</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Select the perfect plan for your needs. All plans include access to our exclusive userscript.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {services.map((service) => (
            <ServiceCard
              key={service.title}
              {...service}
              onPurchase={() => handlePurchase(service.title)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
