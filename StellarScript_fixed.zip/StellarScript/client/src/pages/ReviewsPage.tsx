import { ReviewsSection } from "@/components/ReviewsSection";

export default function ReviewsPage() {
  return (
    <div className="pt-16">
      <ReviewsSection />
    </div>
  );
}
