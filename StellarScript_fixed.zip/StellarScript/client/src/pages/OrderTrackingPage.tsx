import { OrderTracking } from "@/components/OrderTracking";

export default function OrderTrackingPage() {
  return <OrderTracking />;
}
