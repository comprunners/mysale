import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Lock, Loader2 } from "lucide-react";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  price: number;
  productId: string;
}

export default function PaymentModal({ isOpen, onClose, price, productId }: PaymentModalProps) {
  const [name, setName] = useState("");
  const [card, setCard] = useState("");
  const [exp, setExp] = useState("");
  const [cvc, setCvc] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string|undefined>(undefined);
  const [success, setSuccess] = useState<any>(undefined);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(undefined);
    setSuccess(undefined);

    // basic client-side validation
    if (!productId || !price) {
      setError("Missing product data.");
      return;
    }
    if (card.replace(/\D/g,'').length < 12) {
      setError("Please enter a valid card number (mock).");
      return;
    }
    setLoading(true);
    try {
      const resp = await fetch('/api/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId,
          price,
          cardNumber: card,
          exp,
          cvc,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setError(data?.error || 'Payment failed');
      } else {
        setSuccess(data);
      }
    } catch (err: any) {
      setError(err?.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Complete purchase</DialogTitle>
          <DialogDescription>
            Pay ${price} — mock gateway. No real charges.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Name on card</Label>
            <Input id="name" value={name} onChange={(e)=>setName(e.target.value)} placeholder="Jane Doe" />
          </div>

          <div>
            <Label htmlFor="card">Card number</Label>
            <Input id="card" value={card} onChange={(e)=>{
              const v = e.target.value.replace(/\D/g,'');
              setCard(v);
            }} placeholder="4111 1111 1111 1111" />
          </div>

          <div className="flex gap-2">
            <div className="flex-1">
              <Label htmlFor="exp">Expiry (MM/YY)</Label>
              <Input id="exp" value={exp} onChange={(e)=>{
                const v = e.target.value.replace(/[^0-9\/]/g,'');
                setExp(v);
              }} placeholder="12/25" />
            </div>
            <div style={{width:120}}>
              <Label htmlFor="cvc">CVC</Label>
              <Input id="cvc" value={cvc} onChange={(e)=>{
                const v = e.target.value.replace(/\D/g,'').slice(0,4);
                setCvc(v);
              }} placeholder="123" />
            </div>
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}
          {success && <p className="text-sm text-green-600">Payment successful — order id: {success.order?.id}</p>}

          <Button type="submit" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Lock className="mr-2 h-4 w-4" />
                Pay ${price}
              </>
            )}
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            This is a mock payment gateway. No actual charges will be made.
          </p>
        </form>
      </DialogContent>
    </Dialog>
  );
}
